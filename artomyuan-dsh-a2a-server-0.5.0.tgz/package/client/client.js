window.__ModuleLoader__.load({
	id: "@artomyuan/dsh-a2a-server",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
		//#region \0rolldown/runtime.js
		var __create = Object.create;
		var __defProp = Object.defineProperty;
		var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
		var __getOwnPropNames = Object.getOwnPropertyNames;
		var __getProtoOf = Object.getPrototypeOf;
		var __hasOwnProp = Object.prototype.hasOwnProperty;
		var __copyProps = (to, from, except, desc) => {
			if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
				key = keys[i];
				if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
					get: ((k) => from[k]).bind(null, key),
					enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
				});
			}
			return to;
		};
		var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, "default") ? __defProp(target, "default", {
			value: mod,
			enumerable: true
		}) : target, mod));
		//#endregion
		let react = require("react");
		let _deepseek_ai_dsh_client_ui_primitives = require("@deepseek-ai/dsh-client-ui-primitives");
		_deepseek_ai_dsh_client_ui_primitives = __toESM(_deepseek_ai_dsh_client_ui_primitives, 1);
		let react_jsx_runtime = require("react/jsx-runtime");
		//#region src/client/primitive-symbols.ts
		/**
		* 跨版本宿主符号的**纯函数**解析层（无 React、无 JSX，可在 node 里独立单测）。
		*
		* 为什么需要它：浏览器半边与宿主包之间是 **bundle external** 关系——产物里以
		* 「命名空间属性访问」形态引用宿主模块（编译产出形如
		* `_deepseek_ai_dsh_client_ui_primitives.Tag`）。因此**静态按名导入一个宿主没有的
		* 导出不会构建失败、也不会链接失败，只会在运行时得到 `undefined`**；把它当
		* 组件渲染即 React #130（element type is invalid），而且只在 details 维度炸
		* （summary 不渲染该符号）——正是 2026-10-05 浏览器实测抓到的崩溃形态。
		*
		* 实测的两版差异（`@deepseek-ai/dsh-client-ui-primitives`）：
		*  - 图标命名：0.1.5 用**尺寸后缀**（`IconChevronDownOutline14`）；0.2.0 改为
		*    **变体后缀**（`IconChevronDownOutlineRegular` 1px / `…Medium` 1.3px），
		*    `…14` 在 0.2.0 全树零命中。
		*  - `Tag` 在两版契约一致（`TagTone` 取值集合逐字相同），但仍按同一套机制解析，
		*    避免「某天某版改掉它」时重演同一类崩溃。
		*
		* 结论：**按候选名列表运行时解析 + 本地兜底**，两端都不再依赖单一版本的符号面。
		*/
		/** React 可接受的元素类型判定：函数组件 / 字符串（内置标签）/ 带 $$typeof 的 memo·forwardRef 包装 */
		function isComponentType(value) {
			if (typeof value === "function" || typeof value === "string") return true;
			return typeof value === "object" && value !== null && "$$typeof" in value;
		}
		/**
		* 按候选名顺序解析宿主模块上的组件符号，取第一个可用者。
		*
		* @param source - 宿主模块的命名空间对象（可整体缺省/异常形状）
		* @param names - 候选导出名，**按版本优先级排列**
		* @returns 解析到的可渲染组件类型；全部缺失时返回 `undefined`（由调用方走本地兜底）
		*/
		function resolveComponent(source, names) {
			if (source === void 0 || source === null) return void 0;
			for (const name of names) {
				const candidate = source[name];
				if (isComponentType(candidate)) return candidate;
			}
		}
		/**
		* 折叠箭头图标的候选名（按优先级）：
		* 0.1.5 的尺寸后缀命名优先（保持既有观感），随后是 0.2.0 的变体命名，
		* 最后是 0.2.0 的基名兜底。全缺失时由本地 SVG 兜底。
		*/
		const CHEVRON_DOWN_CANDIDATES = [
			"IconChevronDownOutline14",
			"IconChevronDownOutlineRegular",
			"IconChevronDownOutlineMedium",
			"IconChevronDownOutline"
		];
		/** 标签胶囊的候选名（两版同名；保留列表形态以便同一套机制扩展） */
		const TAG_CANDIDATES = ["Tag"];
		//#endregion
		//#region src/client/primitives.tsx
		/**
		* 宿主原语的**运行时解析 + 本地兜底**包装（浏览器半边）。
		*
		* 卡片不再静态按名导入宿主符号，而是经 {@link resolveComponent} 从宿主模块的
		* 命名空间对象上按候选名解析（见 `primitive-symbols.ts` 的机制说明）。解析不到
		* 时改用本文件里的本地实现，保证**任一版本上都不会渲染 `undefined`**（React #130）。
		*
		* 兜底不是临时补丁：0.2.0 已把图标命名从尺寸后缀换成变体后缀，同类改名今后仍可能
		* 发生；本地兜底让卡片对宿主图标面的变化免疫，而宿主提供的符号仍优先使用，观感
		* 与宿主保持一致。
		*/
		const host = _deepseek_ai_dsh_client_ui_primitives;
		/** 解析到的宿主箭头图标（0.1.5 或 0.2.0 的任一候选名），缺失即 undefined */
		const HostChevronDown = resolveComponent(host, CHEVRON_DOWN_CANDIDATES);
		/** 解析到的宿主 Tag，缺失即 undefined */
		const HostTag = resolveComponent(host, TAG_CANDIDATES);
		/**
		* 本地绘制的 14px 折叠箭头（宿主无任何候选图标时使用）。
		* 尺寸/线宽/圆角对齐 0.1.5 `IconChevronDownOutline14` 的观感，颜色随 currentColor。
		*/
		function LocalChevronDown() {
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("svg", {
				width: "14",
				height: "14",
				viewBox: "0 0 14 14",
				fill: "none",
				"aria-hidden": "true",
				focusable: "false",
				children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)("path", {
					d: "M3.75 5.5 7 8.75 10.25 5.5",
					stroke: "currentColor",
					strokeWidth: "1.2",
					strokeLinecap: "round",
					strokeLinejoin: "round"
				})
			});
		}
		/** 本地标签胶囊兜底样式（近似宿主 `Tag tone="neutral"` 的观感） */
		const localTagStyle = {
			display: "inline-flex",
			alignItems: "center",
			height: "18px",
			padding: "0 6px",
			borderRadius: "4px",
			fontSize: "11px",
			lineHeight: 1,
			color: "var(--dsw-alias-label-secondary)",
			background: "var(--dsw-alias-bg-base)",
			border: "0.5px solid var(--dsw-alias-border-l2)"
		};
		/**
		* 折叠箭头：优先宿主图标（保持与宿主观感一致），缺失时用本地 SVG。
		* @returns 可渲染元素
		*/
		function ChevronDown() {
			return HostChevronDown ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(HostChevronDown, {}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)(LocalChevronDown, {});
		}
		/**
		* 中性标签胶囊：优先宿主 `Tag`，缺失时用本地胶囊，两者都只吃 children。
		* @param props.children - 标签文案
		* @returns 可渲染元素
		*/
		function SettingsTag({ children }) {
			return HostTag ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)(HostTag, {
				tone: "neutral",
				children
			}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
				style: localTagStyle,
				children
			});
		}
		//#endregion
		//#region src/client/A2ASettingsCard.tsx
		/**
		* A2A Server 设置卡片：读取 `a2a-server` settings 命名空间的快照，分组渲染
		* 「即时生效」与「重启后生效」字段。全部自持：内联样式（不用 CSS Modules，
		* 避免引入 lightningcss 构建链）、无跨插件 value import。
		*
		* 卡片头是折叠开关（官方 PluginCard 同款交互）：默认收起，点击标题在展开/
		* 收起间切换，保存成功后自动收起、失败则保持展开并保留草稿。折叠是本卡的
		* 阅读状态，草稿由 controller 持有，收起不丢改动；带头在收起态显示「未保存」
		* 标记。头按钮带 aria-expanded 与 aria-label（双语字典）。
		*
		* 根节点始终带 data-testid / data-ns / data-scope-status（外加 data-open 与
		* 头/体/未保存标记的 data-testid），非 ready 时只加 `hidden` 而不返回 null
		* ——CDP 可用 DOM 存在性判定卡片「真渲染」（决策 C9）。
		*/
		const cardStyle = {
			listStyle: "none",
			fontFamily: "inherit",
			fontSize: "13px",
			lineHeight: 1.5,
			color: "inherit",
			border: "0.5px solid var(--dsw-alias-border-l4)",
			borderRadius: "16px",
			background: "var(--dsw-alias-bg-layer-3)",
			transition: "border-color .16s, background .16s"
		};
		/** 展开态读作「正在编辑的那张卡」，而不只是变高了 */
		const cardOpenStyle = {
			background: "var(--dsw-alias-bg-layer-2)",
			borderColor: "var(--dsw-alias-label-dimmed)"
		};
		const headerStyle = {
			width: "100%",
			appearance: "none",
			border: 0,
			background: "none",
			font: "inherit",
			color: "inherit",
			textAlign: "left",
			cursor: "pointer",
			display: "flex",
			alignItems: "center",
			gap: "12px",
			padding: "14px 16px",
			borderRadius: "12px"
		};
		const headTextStyle = {
			flex: 1,
			minWidth: 0,
			display: "flex",
			flexDirection: "column",
			gap: "4px"
		};
		const nameStyle = {
			fontSize: "15px",
			fontWeight: 600,
			lineHeight: 1.4,
			color: "var(--dsw-alias-label-primary)"
		};
		const descriptionStyle = {
			fontSize: "13px",
			lineHeight: 1.5,
			color: "var(--dsw-alias-label-tertiary)"
		};
		/** 未保存标记的定位壳（胶囊外观由 Tag 提供；Tag 不接受 data-* 透传） */
		const pendingStyle = {
			flex: "none",
			display: "inline-flex"
		};
		const chevronStyle = {
			flex: "none",
			display: "inline-flex",
			color: "var(--dsw-alias-label-tertiary)",
			transition: "transform .16s"
		};
		const chevronOpenStyle = { transform: "rotate(180deg)" };
		const bodyStyle = {
			borderTop: "0.5px solid var(--dsw-alias-border-l2)",
			margin: "0 16px",
			paddingTop: "12px",
			paddingBottom: "8px"
		};
		const groupStyle = { marginBottom: "14px" };
		const groupLabelStyle = {
			margin: "0 0 2px",
			fontSize: "13px",
			fontWeight: 600
		};
		const groupHintStyle = {
			margin: "0 0 6px",
			fontSize: "12px",
			opacity: .6
		};
		const rowStyle = {
			display: "flex",
			flexWrap: "wrap",
			alignItems: "center",
			gap: "6px 10px",
			padding: "6px 0",
			borderTop: "1px solid rgba(128, 128, 128, 0.18)"
		};
		const labelStyle = {
			flex: "0 0 130px",
			fontSize: "13px"
		};
		const inputStyle = {
			flex: "1 1 220px",
			minWidth: 0,
			padding: "5px 8px",
			fontSize: "13px",
			fontFamily: "inherit",
			color: "inherit",
			background: "transparent",
			border: "1px solid rgba(128, 128, 128, 0.4)",
			borderRadius: "4px"
		};
		const badgeStyle = {
			padding: "1px 6px",
			fontSize: "11px",
			borderRadius: "3px",
			border: "1px solid rgba(128, 128, 128, 0.4)",
			opacity: .85
		};
		const dangerBadgeStyle = {
			...badgeStyle,
			borderColor: "rgba(224, 96, 64, 0.8)",
			color: "#e06040"
		};
		const envBadgeStyle = {
			...badgeStyle,
			borderColor: "rgba(64, 128, 224, 0.8)",
			color: "#4080e0"
		};
		const buttonStyle = {
			padding: "4px 10px",
			fontSize: "12px",
			fontFamily: "inherit",
			color: "inherit",
			background: "transparent",
			border: "1px solid rgba(128, 128, 128, 0.5)",
			borderRadius: "4px",
			cursor: "pointer"
		};
		const primaryButtonStyle = {
			...buttonStyle,
			borderColor: "rgba(64, 128, 224, 0.9)",
			color: "#4080e0"
		};
		const fieldHintStyle = {
			flexBasis: "100%",
			margin: "2px 0 0 140px",
			fontSize: "12px",
			opacity: .6
		};
		const invalidStyle = {
			flexBasis: "100%",
			margin: "2px 0 0 140px",
			fontSize: "12px",
			color: "#e06040"
		};
		const footerStyle = {
			display: "flex",
			alignItems: "center",
			justifyContent: "flex-end",
			gap: "10px",
			marginTop: "10px"
		};
		const failedStyle = {
			flex: 1,
			minWidth: 0,
			fontSize: "12px",
			color: "#e06040"
		};
		/** 字段 → 标签/提示文案键（静态映射，t 保持类型检查） */
		const FIELD_LABEL_KEYS = {
			provider: "fieldProvider",
			model: "fieldModel",
			preset: "fieldPreset",
			cwd: "fieldCwd",
			port: "fieldPort",
			host: "fieldHost",
			contextMapPath: "fieldContextMapPath",
			contextMapTtlDays: "fieldContextMapTtlDays"
		};
		const FIELD_HINT_KEYS = {
			provider: "fieldProviderHint",
			model: "fieldModelHint",
			preset: "fieldPresetHint",
			cwd: "fieldCwdHint",
			port: "fieldPortHint",
			host: "fieldHostHint",
			contextMapPath: "fieldContextMapPathHint",
			contextMapTtlDays: "fieldContextMapTtlDaysHint"
		};
		/** 字段行：标签 + 输入 + 覆盖标记/清除 + 生效时机提示 */
		function FieldRow(props) {
			const { t, label, hint, field, state, disabled, onEdit, onClear } = props;
			const fieldState = state.fields[field];
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
				style: rowStyle,
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
						style: labelStyle,
						children: label
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
						style: inputStyle,
						type: field === "port" || field === "contextMapTtlDays" ? "number" : "text",
						value: fieldState.text,
						disabled,
						onChange: (event) => {
							onEdit(field, event.target.value);
						}
					}),
					fieldState.overridden ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
						style: badgeStyle,
						children: t("overridden")
					}) : null,
					fieldState.overridden ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
						style: buttonStyle,
						disabled,
						onClick: () => {
							onClear(field);
						},
						children: t("clearOverride")
					}) : null,
					fieldState.invalid !== null ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
						style: invalidStyle,
						children: t(fieldState.invalid)
					}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
						style: fieldHintStyle,
						children: hint
					})
				]
			});
		}
		/**
		* 渲染卡片。
		* @param props - locale 座位、绑定好的 useA2aSettings 钩子与表单动作
		* @returns 卡片根节点（始终带判定属性，见模块注释）
		*/
		function A2ASettingsCard(props) {
			const { t } = props;
			const state = props.useA2aSettings((snapshot) => snapshot);
			const [open, setOpen] = (0, react.useState)(false);
			const [confirmClearToken, setConfirmClearToken] = (0, react.useState)(false);
			const saveStarted = (0, react.useRef)(false);
			const ready = state.status === "ready";
			const disabled = !state.writable || state.saving;
			(0, react.useEffect)(() => {
				if (state.saving) {
					saveStarted.current = true;
					return;
				}
				if (!saveStarted.current) return;
				saveStarted.current = false;
				if (!state.dirty && !state.failed) setOpen(false);
			}, [
				state.dirty,
				state.failed,
				state.saving
			]);
			if (props.view === "summary") return t("a2aDescription");
			const liveFields = [
				"provider",
				"model",
				"preset",
				"cwd",
				"contextMapTtlDays"
			];
			const restartFields = [
				"port",
				"host",
				"contextMapPath"
			];
			const token = state.fields.authToken;
			const tokenDisabled = disabled || token.envToken;
			const title = t("a2aTitle");
			return /* @__PURE__ */ (0, react_jsx_runtime.jsx)("li", {
				style: open ? {
					...cardStyle,
					...cardOpenStyle
				} : cardStyle,
				hidden: !ready || void 0,
				"data-testid": "a2a-server-card",
				"data-ns": "a2a-server",
				"data-scope-status": state.status,
				"data-open": open ? "true" : "false",
				children: !ready ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
					style: {
						margin: 0,
						padding: "14px 16px"
					},
					children: state.status === "loading" ? t("loading") : t("unavailable")
				}) : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)(react_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("button", {
					type: "button",
					style: headerStyle,
					"data-testid": "a2a-server-card-header",
					"aria-expanded": open,
					"aria-label": `${t(open ? "collapse" : "expand")}: ${title}`,
					onClick: () => {
						setOpen(!open);
					},
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
							style: headTextStyle,
							children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								style: nameStyle,
								children: title
							}), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
								style: descriptionStyle,
								children: t("a2aDescription")
							})]
						}),
						state.dirty ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
							style: pendingStyle,
							"data-testid": "a2a-server-card-unsaved",
							children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(SettingsTag, { children: t("unsaved") })
						}) : null,
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
							style: open ? {
								...chevronStyle,
								...chevronOpenStyle
							} : chevronStyle,
							children: /* @__PURE__ */ (0, react_jsx_runtime.jsx)(ChevronDown, {})
						})
					]
				}), open ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
					style: bodyStyle,
					"data-testid": "a2a-server-card-body",
					children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							style: groupStyle,
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
									style: groupLabelStyle,
									children: t("groupLive")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
									style: groupHintStyle,
									children: t("groupLiveHint")
								}),
								liveFields.map((field) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)(FieldRow, {
									t,
									label: t(FIELD_LABEL_KEYS[field]),
									hint: t(FIELD_HINT_KEYS[field]),
									field,
									state,
									disabled,
									onEdit: props.edit,
									onClear: props.clearOverride
								}, field)),
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
									style: rowStyle,
									children: [
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											style: labelStyle,
											children: t("fieldAuthToken")
										}),
										/* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
											style: inputStyle,
											type: "password",
											value: token.text,
											disabled: tokenDisabled,
											placeholder: t("authTokenPlaceholder"),
											onChange: (event) => {
												props.edit("authToken", event.target.value);
											}
										}),
										token.envToken ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											style: envBadgeStyle,
											children: t("authTokenEnvBadge")
										}) : token.configured ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											style: badgeStyle,
											children: t("authTokenSet")
										}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											style: dangerBadgeStyle,
											children: t("authTokenUnsetDanger")
										}),
										token.configured && !token.envToken ? confirmClearToken ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", { children: [
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
												style: fieldHintStyle,
												children: t("authTokenClearConfirmText")
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
												style: dangerBadgeStyle,
												disabled,
												onClick: () => {
													setConfirmClearToken(false);
													props.clearAuthToken();
												},
												children: t("confirm")
											}),
											/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
												style: buttonStyle,
												onClick: () => {
													setConfirmClearToken(false);
												},
												children: t("cancel")
											})
										] }) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
											style: buttonStyle,
											disabled,
											onClick: () => {
												setConfirmClearToken(true);
											},
											children: t("clearOverride")
										}) : null,
										token.envToken ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
											style: fieldHintStyle,
											children: t("authTokenEnvHint")
										}) : token.configured ? null : /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("span", {
											style: fieldHintStyle,
											children: [
												t("authTokenUnset"),
												" — ",
												t("fieldAuthTokenHint")
											]
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							style: groupStyle,
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
									style: groupLabelStyle,
									children: t("groupRestart")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
									style: groupHintStyle,
									children: t("groupRestartHint")
								}),
								restartFields.map((field) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)(FieldRow, {
									t,
									label: t(FIELD_LABEL_KEYS[field]),
									hint: t(FIELD_HINT_KEYS[field]),
									field,
									state,
									disabled,
									onEdit: props.edit,
									onClear: props.clearOverride
								}, field))
							]
						}),
						/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
							style: footerStyle,
							children: [
								state.failed ? /* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
									style: failedStyle,
									children: t("saveFailed")
								}) : null,
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
									style: buttonStyle,
									disabled: disabled || !state.dirty,
									onClick: () => {
										props.discard();
									},
									children: t("discard")
								}),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
									style: primaryButtonStyle,
									disabled: disabled || !state.dirty || state.invalid,
									onClick: () => {
										props.save();
									},
									children: t("save")
								})
							]
						})
					]
				}) : null] })
			});
		}
		//#endregion
		//#region src/client/card-controller.ts
		/** 命名空间名 = host 半边注册的名字（src/settings.ts 同值，客户端不能 import host） */
		const A2A_SETTINGS_NS = "a2a-server";
		/** 环境令牌变量：host 侧 applyResolvedConfig 里的最高优先级通道 */
		const ENV_TOKEN = "A2A_SERVER_TOKEN";
		/**
		* 0.1.5 `SettingsScope` → {@link A2AFormSource} 适配器：把写方法的
		* `Promise<void>`（被拒时静默 recover 重读，不抛）包装成 `Promise<boolean>`。
		* 「被拒但已 recover」的情况由控制器保存后的 {@link A2ASettingsCardController.verifyLanded}
		* 读回 userLayer 判定，保持既有 0.1.5 行为不变；wire 层异常返回 false。
		*/
		function legacyScopeSource(scope) {
			return {
				getSnapshot: () => scope.getSnapshot(),
				subscribe: (listener) => scope.subscribe(listener),
				mutate: async (ops, revision) => {
					try {
						await scope.mutate(ops, revision);
						return true;
					} catch {
						return false;
					}
				},
				set: async (field, value) => {
					try {
						await scope.set(field, value);
						return true;
					} catch {
						return false;
					}
				},
				unset: async (field) => {
					try {
						await scope.unset(field);
						return true;
					} catch {
						return false;
					}
				}
			};
		}
		const FIELD_SPECS = [
			{
				kind: "text",
				field: "provider"
			},
			{
				kind: "text",
				field: "model"
			},
			{
				kind: "text",
				field: "preset"
			},
			{
				kind: "text",
				field: "cwd"
			},
			{
				kind: "text",
				field: "contextMapPath"
			},
			{
				kind: "number",
				field: "port",
				min: 1,
				max: 65535,
				invalidKey: "invalidPort"
			},
			{
				kind: "text",
				field: "host"
			},
			{
				kind: "number",
				field: "contextMapTtlDays",
				min: 1,
				max: 2147483647,
				invalidKey: "invalidTtl"
			}
		];
		/** 最小快照 store（getSnapshot/subscribe/set；替代 dsh-client-store 的 value import） */
		var CardStore = class {
			snapshot;
			listeners = /* @__PURE__ */ new Set();
			constructor(initial) {
				this.snapshot = initial;
			}
			getSnapshot() {
				return this.snapshot;
			}
			subscribe(listener) {
				this.listeners.add(listener);
				return () => {
					this.listeners.delete(listener);
				};
			}
			set(next) {
				this.snapshot = next;
				for (const listener of [...this.listeners]) listener();
			}
		};
		/**
		* 桥接 `a2a-server` scope：暂存草稿、投影卡片状态、带 revision 乐观锁保存。
		*/
		var A2ASettingsCardController = class {
			source;
			store;
			staged = /* @__PURE__ */ new Map();
			describe;
			saving = false;
			failed = false;
			/** 草稿起始时冻结的 revision（乐观锁栅栏）；保存后刷新为最新 revision */
			fenceRevision;
			envToken = false;
			/**
			* @param source - `a2a-server` 的统一表单后端（0.1.5 经 legacyScopeSource 适配，
			*   0.2.0 直接传 configForms.get 的结果）
			* @param describe - 共享 describe 镜像（读 secret 的 set 状态）
			* @param ctx - 卡片所在 fiber 的 context（用于可选地注入 credentials Remote）
			*/
			constructor(source, describe, ctx) {
				this.source = source;
				this.describe = describe;
				this.store = new CardStore(this.projection());
				source.subscribe(() => {
					this.publish();
				});
				describe.subscribe(() => {
					this.publish();
				});
				ctx.inject(["remote.credentials"], (credCtx) => {
					this.readEnvToken(credCtx.remote.credentials);
				});
			}
			/** 读取环境令牌状态（一次；环境在会话期内不变） */
			async readEnvToken(credentials) {
				try {
					const response = await credentials.describe([ENV_TOKEN]);
					if (!response.ok) return;
					const info = response.value[ENV_TOKEN];
					if (info?.configured === true && info.source === "env") {
						this.envToken = true;
						this.publish();
					}
				} catch {}
			}
			/** 保存当前 revision 快照里的 scope 数据 */
			snapshot() {
				return this.source.getSnapshot();
			}
			/** 用户层（原始存储段）或 undefined */
			userLayer() {
				const user = this.snapshot().user;
				return user !== null && typeof user === "object" ? user : void 0;
			}
			/** 用户层是否持有该字段（overridden 标记的事实源） */
			stored(field) {
				const user = this.userLayer();
				return user !== void 0 && Object.hasOwn(user, field);
			}
			/** 有效值（schema 默认 < base < user 解析后）里该字段的显示文本 */
			effectiveText(field) {
				const value = this.snapshot().value?.[field];
				return typeof value === "number" || typeof value === "string" ? String(value) : "";
			}
			/** base 层里该字段的回落文本 */
			baseText(field) {
				const value = this.snapshot().base?.[field];
				return typeof value === "number" || typeof value === "string" ? String(value) : "";
			}
			/** 草稿文本经 spec 解析后的写入意图；undefined = 不可保存 */
			parse(field, text) {
				const spec = FIELD_SPECS.find((candidate) => candidate.field === field);
				if (spec === void 0) throw new Error(`A2A settings card has no field ${field}`);
				const trimmed = text.trim();
				if (trimmed === "") return { op: "clear" };
				if (spec.kind === "number") {
					const parsed = Number(trimmed);
					if (!Number.isInteger(parsed) || parsed < spec.min || parsed > spec.max) return void 0;
					return {
						op: "set",
						value: parsed
					};
				}
				return {
					op: "set",
					value: trimmed
				};
			}
			/** 一个普通字段的渲染状态 */
			fieldState(field) {
				const spec = FIELD_SPECS.find((candidate) => candidate.field === field);
				const staged = this.staged.get(field);
				if (staged === void 0) return {
					text: this.effectiveText(field),
					baseText: this.baseText(field),
					overridden: this.stored(field),
					invalid: null
				};
				const write = this.parse(field, staged.text);
				if (staged.text.trim() === "") return {
					text: staged.text,
					baseText: this.baseText(field),
					overridden: false,
					invalid: null
				};
				return {
					text: staged.text,
					baseText: this.baseText(field),
					overridden: true,
					invalid: write === void 0 ? spec.kind === "number" ? spec.invalidKey : null : null
				};
			}
			/** authToken 字段的渲染状态（草稿空白起始，只写不回显） */
			authTokenState() {
				return {
					text: this.staged.get("authToken")?.text ?? "",
					configured: this.secretConfigured(),
					envToken: this.envToken
				};
			}
			/** describe 镜像里 authToken 槽位是否持有值（secret sidecar 的 set 标志） */
			secretConfigured() {
				return (this.describeView()?.secrets.find((entry) => entry.path.length === 1 && entry.path[0] === "authToken"))?.set === true;
			}
			/** describe 镜像里本命名空间的行 */
			describeView() {
				return this.describe.getSnapshot().view?.namespaces.find((row) => row.ns === A2A_SETTINGS_NS);
			}
			/** 投影整个卡片状态 */
			projection() {
				const snapshot = this.snapshot();
				const plan = this.plan();
				const authStaged = this.staged.get("authToken");
				const authDirty = authStaged !== void 0 && authStaged.text.trim() !== "";
				return {
					status: snapshot.status,
					writable: snapshot.writable,
					dirty: plan.ops.length > 0 || authDirty,
					invalid: plan.invalid,
					saving: this.saving,
					failed: this.failed,
					fields: {
						provider: this.fieldState("provider"),
						model: this.fieldState("model"),
						preset: this.fieldState("preset"),
						cwd: this.fieldState("cwd"),
						port: this.fieldState("port"),
						host: this.fieldState("host"),
						contextMapPath: this.fieldState("contextMapPath"),
						contextMapTtlDays: this.fieldState("contextMapTtlDays"),
						authToken: this.authTokenState()
					}
				};
			}
			/** 广播最新投影 */
			publish() {
				this.store.set(this.projection());
			}
			/** 注册注入的业务面 */
			inject() {
				return {
					hooks: { a2aSettings: this.store },
					edit: (field, text) => {
						this.stage(field, text);
					},
					save: () => {
						this.save();
					},
					discard: () => {
						if (this.staged.size === 0 && !this.failed) return;
						this.staged.clear();
						this.failed = false;
						this.fenceRevision = void 0;
						this.publish();
					},
					clearOverride: (field) => {
						this.clear(field);
					},
					clearAuthToken: () => {
						this.clear("authToken");
					}
				};
			}
			/** 暂存草稿；首个草稿落笔时冻结 revision 栅栏 */
			stage(field, text) {
				if (!this.staged.has(field)) this.fenceRevision = this.snapshot().revision;
				this.staged.set(field, { text });
				this.failed = false;
				this.publish();
			}
			/** 把全部草稿解析成一次 mutate 的 ops 序列（含 invalid 标志） */
			plan() {
				const ops = [];
				let invalid = false;
				for (const spec of FIELD_SPECS) {
					const staged = this.staged.get(spec.field);
					if (staged === void 0) continue;
					const write = this.parse(spec.field, staged.text);
					if (write === void 0) {
						invalid = true;
						continue;
					}
					if (write.op === "clear") {
						if (this.stored(spec.field)) ops.push({
							op: "unset",
							path: [spec.field]
						});
					} else if (staged.text.trim() !== this.effectiveText(spec.field)) ops.push({
						op: "set",
						path: [spec.field],
						value: write.value
					});
				}
				const authStaged = this.staged.get("authToken");
				if (authStaged !== void 0) {
					const trimmed = authStaged.text.trim();
					if (trimmed !== "") ops.push({
						op: "set",
						path: ["authToken"],
						value: trimmed
					});
				}
				return {
					ops,
					invalid
				};
			}
			/**
			* 保存全部草稿：一次 mutate + revision 乐观锁，然后按 host 接受的结果回读
			* 验证（host 是唯一权威）。失败保留草稿供修正/重试。
			*/
			async save() {
				const plan = this.plan();
				if (plan.invalid || plan.ops.length === 0 || this.saving) return;
				const revision = this.fenceRevision ?? this.snapshot().revision;
				this.saving = true;
				this.failed = false;
				this.publish();
				let landed = true;
				try {
					landed = await this.source.mutate(plan.ops, revision) && this.verifyLanded(plan.ops);
				} catch {
					landed = false;
				}
				this.saving = false;
				if (landed) {
					this.staged.clear();
					this.failed = false;
				} else this.failed = true;
				this.fenceRevision = this.snapshot().revision;
				this.publish();
			}
			/**
			* 写后回读验证：host 是唯一权威，逐 op 核对 userLayer（或 secret 的 set 标志）
			* 是否已落到期望状态。全部落定返回 true。
			*/
			verifyLanded(ops) {
				const user = this.userLayer();
				let landed = true;
				for (const op of ops) if (op.op === "set") {
					if (op.path[0] === "authToken") landed = this.secretConfigured() && landed;
					else landed = user?.[op.path[0]] === op.value && landed;
				} else landed = (user === void 0 || !Object.hasOwn(user, op.path[0])) && landed;
				return landed;
			}
			/** 立即清除一个字段的用户层覆盖（回落配置层） */
			async clear(field) {
				try {
					if (!await this.source.unset(field)) {
						this.failed = true;
						this.publish();
					}
				} catch {
					this.failed = true;
					this.publish();
				}
			}
		};
		//#endregion
		//#region src/client/locales.ts
		const zh = {
			a2aTitle: "A2A Server",
			a2aDescription: "A2A 服务的运行时参数（provider / model / preset / 工作目录 / 端口 / 访问令牌）。",
			groupLive: "即时生效",
			groupLiveHint: "保存后对下一个 A2A 请求生效。",
			groupRestart: "重启后生效",
			groupRestartHint: "保存后需要重启 dsh 服务才会生效。",
			fieldProvider: "Provider",
			fieldProviderHint: "后端 provider。即时生效；清除覆盖后回落配置层。",
			fieldModel: "模型",
			fieldModelHint: "执行任务的模型；空串 = 跟随 dsh 默认模型。即时生效；清除覆盖后回落配置层。",
			fieldPreset: "Agent preset",
			fieldPresetHint: "挂载到 A2A 会话的 agent preset。即时生效；清除覆盖后回落配置层。",
			fieldCwd: "工作目录",
			fieldCwdHint: "A2A 任务的执行目录；空 = 进程当前目录。即时生效；清除覆盖后回落配置层。",
			fieldPort: "端口",
			fieldPortHint: "监听端口（1–65535 整数）。重启后生效。",
			fieldHost: "监听地址",
			fieldHostHint: "默认 127.0.0.1（仅本机）。不能为空串。重启后生效。",
			fieldContextMapPath: "会话映射文件",
			fieldContextMapPathHint: "contextId→session 映射的持久化路径；空 = 默认位置。重启后生效。",
			fieldContextMapTtlDays: "映射保留天数",
			fieldContextMapTtlDaysHint: "超期映射条目在加载/写入时清理（≥1 整数）。即时生效。",
			fieldAuthToken: "访问令牌",
			fieldAuthTokenHint: "Bearer token；设置后所有请求必须携带。只写不回显。",
			authTokenSet: "已设置",
			authTokenUnset: "未设置",
			authTokenUnsetDanger: "未设置 = 无鉴权（危险）",
			authTokenEnvBadge: "由环境变量接管",
			authTokenEnvHint: "进程环境存在 A2A_SERVER_TOKEN，优先级最高，此处写入不会生效。",
			authTokenPlaceholder: "输入新令牌（留空 = 不修改）",
			authTokenClearConfirm: "确认清除访问令牌覆盖？",
			authTokenClearConfirmText: "令牌将回落到 cordis.patch.yml 中的既有令牌；若配置层也未设置，服务将变为无鉴权。",
			overridden: "已被用户层覆盖",
			clearOverride: "清除覆盖",
			save: "保存",
			discard: "放弃修改",
			saveFailed: "保存失败：配置已被其他会话修改，请重试。",
			invalidPort: "端口必须是 1–65535 的整数",
			invalidHost: "监听地址不能为空",
			invalidTtl: "保留天数必须是 ≥1 的整数",
			loading: "正在读取配置…",
			unavailable: "设置服务不可用（该命名空间未对本客户端开放）。",
			confirm: "确认清除",
			cancel: "取消",
			expand: "展开",
			collapse: "收起",
			unsaved: "未保存"
		};
		const en = {
			a2aTitle: "A2A Server",
			a2aDescription: "Runtime parameters of the A2A service (provider / model / preset / working directory / port / access token).",
			groupLive: "Takes effect immediately",
			groupLiveHint: "Applies to the next A2A request after saving.",
			groupRestart: "Takes effect after restart",
			groupRestartHint: "Applies only after the dsh service restarts.",
			fieldProvider: "Provider",
			fieldProviderHint: "Backend provider. Immediate; clearing the override falls back to the config layer.",
			fieldModel: "Model",
			fieldModelHint: "Model for task execution; empty = follow the dsh default. Immediate; clearing falls back to the config layer.",
			fieldPreset: "Agent preset",
			fieldPresetHint: "Agent preset mounted onto A2A sessions. Immediate; clearing falls back to the config layer.",
			fieldCwd: "Working directory",
			fieldCwdHint: "Execution directory of A2A tasks; empty = process cwd. Immediate; clearing falls back to the config layer.",
			fieldPort: "Port",
			fieldPortHint: "Listen port (integer 1–65535). Applies after restart.",
			fieldHost: "Listen address",
			fieldHostHint: "Defaults to 127.0.0.1 (local only). Must not be empty. Applies after restart.",
			fieldContextMapPath: "Session map file",
			fieldContextMapPathHint: "Persistence path of the contextId→session map; empty = default location. Applies after restart.",
			fieldContextMapTtlDays: "Map retention days",
			fieldContextMapTtlDaysHint: "Expired map entries are cleaned on load/write (integer ≥ 1). Immediate.",
			fieldAuthToken: "Access token",
			fieldAuthTokenHint: "Bearer token; when set, every request must carry it. Write-only, never echoed back.",
			authTokenSet: "Set",
			authTokenUnset: "Not set",
			authTokenUnsetDanger: "Not set = no authentication (dangerous)",
			authTokenEnvBadge: "Overridden by environment",
			authTokenEnvHint: "The process environment carries A2A_SERVER_TOKEN; it wins over this field, so writes here have no effect.",
			authTokenPlaceholder: "Enter a new token (blank = no change)",
			authTokenClearConfirm: "Clear the access-token override?",
			authTokenClearConfirmText: "The token falls back to the existing one in cordis.patch.yml; if the config layer sets none either, the service becomes unauthenticated.",
			overridden: "Overridden by the user layer",
			clearOverride: "Clear override",
			save: "Save",
			discard: "Discard changes",
			saveFailed: "Save failed: the configuration changed in another session, please retry.",
			invalidPort: "Port must be an integer between 1 and 65535",
			invalidHost: "Listen address must not be empty",
			invalidTtl: "Retention days must be an integer ≥ 1",
			loading: "Loading configuration…",
			unavailable: "Settings service unavailable (the namespace is not exposed to this client).",
			confirm: "Confirm clear",
			cancel: "Cancel",
			expand: "Expand",
			collapse: "Collapse",
			unsaved: "Unsaved"
		};
		//#endregion
		//#region src/client/mount-strategy.ts
		/**
		* 依据能力事实选择卡片挂载路径：
		*  - 两者都有 → `legacy`（0.1.5 优先，不回归）；
		*  - 只有 settingsScope → `legacy`；
		*  - 只有 configForms → `modern`；
		*  - 都没有 / 缺省 / undefined → `none`。
		*
		* @param caps - 能力探测结果（可整体缺省）
		*/
		function pickClientMount(caps = {}) {
			if (caps.hasSettingsScope) return "legacy";
			if (caps.hasConfigForms) return "modern";
			return "none";
		}
		//#endregion
		//#region src/client/index.ts
		/** Cordis 插件名 */
		const name = "@artomyuan/dsh-a2a-server";
		/** 依赖的服务（settingsScope / configForms 走嵌套 inject，见模块注释） */
		const inject = ["slots", "locale"];
		/** 文案命名空间（双字典键集一致，见 locales.ts） */
		const NS = "settings.a2aServer";
		/**
		* 挂载设置卡片：注册字典 + 按能力探测走 legacy（0.1.5）或 modern（0.2.0）路径。
		* 两条路径互斥：共享 `mounted` 标志保证同一实例只挂一次。
		* @param ctx - 浏览器插件 context
		*/
		function apply(ctx) {
			ctx.effect(() => ctx.locale.register(NS, {
				zh,
				en
			}), "dsh-a2a-server: card dictionaries");
			const t = ctx.locale.bind(NS);
			/** 0.1.5 与 0.2.0 的设置服务跨版本互斥，正常 host 上只触发其一；标志防病态双服务 */
			let mounted;
			ctx.inject(["settingsScope"], (scoped) => {
				const strategy = pickClientMount({
					hasSettingsScope: scoped.get("settingsScope") !== void 0,
					hasConfigForms: scoped.get("configForms") !== void 0
				});
				if (mounted !== void 0 || strategy !== "legacy") return;
				mounted = strategy;
				const controller = new A2ASettingsCardController(legacyScopeSource(scoped.settingsScope.bind({ namespace: A2A_SETTINGS_NS })), scoped.settingsScope.describe(), scoped);
				scoped.slots.inject("settings.plugin.item", () => scoped.slots.register({
					name: "settings.plugin.item",
					key: A2A_SETTINGS_NS,
					locale: NS,
					inject: () => controller.inject()
				}, A2ASettingsCard));
			});
			ctx.inject(["configForms"], (scoped) => {
				const strategy = pickClientMount({
					hasSettingsScope: scoped.get("settingsScope") !== void 0,
					hasConfigForms: scoped.get("configForms") !== void 0
				});
				if (mounted !== void 0 || strategy !== "modern") return;
				mounted = strategy;
				const configForms = scoped.configForms;
				const controller = new A2ASettingsCardController(configForms.get(A2A_SETTINGS_NS), configForms.describe(), scoped);
				ctx.effect(() => configForms.whileServed([A2A_SETTINGS_NS], () => scoped.slots.inject("plugins.item", () => scoped.slots.register({
					name: "plugins.item",
					id: A2A_SETTINGS_NS,
					order: 50,
					label: () => t("a2aTitle"),
					locale: NS,
					inject: () => controller.inject()
				}, A2ASettingsCard))), "dsh-a2a-server: page");
			});
		}
		//#endregion
		exports.apply = apply;
		exports.inject = inject;
		exports.name = name;
		return module.exports;
	}
});

//# sourceMappingURL=client.js.map