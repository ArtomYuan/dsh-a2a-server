/**
 * dsh-a2a-server — 在 dsh profile 内启动 A2A (Agent2Agent) server，把 dsh
 * agent 会话通过 A2A 协议暴露给远端 agent（如 Hermes）。
 *
 * P0 最小闭环：
 *   - node:http 常驻 listener（Bearer token 认证 + 路由），挂
 *     `@a2a-js/sdk` v1.1.0 的 `JsonRpcTransportHandler`。
 *   - `AgentExecutor` 把 A2A task 的文本同步投给 dsh agent 会话执行，最终
 *     assistant 输出作为 A2A artifact 返回。
 *
 * P1 contextId 会话映射：
 *   - A2A `message.contextId`（Hermes 传 origin 派生）→ dsh 会话键。同
 *     contextId 复用同一 dsh 会话（上下文连续），异 contextId 隔离。
 *   - 两级接管：持久映射命中 → `ctx.agents.resume`；未命中 → 新建 + 写映射。
 *     映射持久化到 `$DSH_HOME/storages/a2a-context-map.json`，跨重启续接。
 *
 * P2a 流式中间事件 + 映射清理：
 *   - `SendStreamingMessage` 流式模式下，订阅 dsh agent 的事件面，把思考/工具/
 *     状态/文本等中间事件作为 A2A `artifactUpdate`（文本用 text Part、非文本用
 *     data Part 私有扩展）实时推给客户端。助手增量有双事件面（A6，见
 *     `src/compat.ts`）：0.1.5 走 `session/event` 的 `assistant/chunk`，0.2.0 走
 *     进程内事件 `agent/assistant-stream`，两面共用同一缓冲状态机并单向去重。
 *   - contextMap 每条目记 lastUsedAt，TTL（默认 7 天）清理过期孤儿条目。
 *
 * P3 工作区自动归组：
 *   - 新建会话后自动登记到其 cwd 对应的工作区；启动时对存量未分组会话批量捞回补挂。
 */

import type { Context } from '@deepseek-ai/cordis'
// 类型声明合并：让 ctx.agents / ctx.agentPresets 在 Context 上有类型
import type {} from '@deepseek-ai/dsh-agent'
import type {} from '@deepseek-ai/dsh-agent-presets'
// 注（A5）：0.2.0 侧的 preset 服务包 @deepseek-ai/dsh-agent-preset-registry
// 已列为 optional peer + devDependency，但这里刻意不做 `import type {}`——
// 实测其 0.2.0 类型链会把 schemastery 的 Schema/Mode 全局增强进 0.1.x 的
// 类型检查程序，导致本包 settings schema 声明不再通过 typecheck（两个版本的
// 类型增强冲突）。运行时无类型需求（0.2.0 上该包提供同名 agentPresets 服务），
// 保留依赖仅为版本门/锁文件准备，详见 IMPL-STATUS。
import type { AgentHandle } from '@deepseek-ai/dsh-agent'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import { SessionId } from '@deepseek-ai/dsh-session'
import type { SessionHeader } from '@deepseek-ai/dsh-session'
import { scopeOf } from '@deepseek-ai/dsh-scope'
import { AsyncLocalStorage } from 'node:async_hooks'
import { randomUUID } from 'node:crypto'
import http from 'node:http'
import { mkdir, readFile, realpath, rename, writeFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import {
  A2A_PROTOCOL_VERSION,
  AGENT_CARD_PATH,
  TaskState,
  formatSSEEvent,
} from '@a2a-js/sdk'
import type { AgentCard, Part } from '@a2a-js/sdk'
import {
  AgentEvent,
  DefaultRequestHandler,
  InMemoryTaskStore,
  JsonRpcTransportHandler,
  ServerCallContext,
} from '@a2a-js/sdk/server'
import type { AgentExecutor, ExecutionEventBus, RequestContext } from '@a2a-js/sdk/server'
import { installA2ASettings, A2AConfigSchema, A2ASettingsSchema } from './settings.ts'
import type { A2ASettings } from './settings.ts'
import {
  applyAssistantStreamFrame,
  applySessionAssistantChunk,
  assistantStreamTurnStep,
  createAssistantIngestState,
  dshRuntimeVersion,
  pluginMessageSourceFor,
  readToolResult,
  sourceModeForSessionVersion,
  supportsAssistantStreamEvents,
  unwrapVolatile,
  type AssistantStreamFrameView,
  type PluginMessageSourceMode,
} from './compat.ts'

/** 投递后等待 turn/start 的宽限期；超时即换另一种消息 source 形状重试（A1 兜底） */
const TURN_START_GRACE_MS = 2000

/** Cordis 插件名 */
export const name = '@artomyuan/dsh-a2a-server'

/** 声明依赖的核心服务（必须与代码里的 ctx.get / 直接调用对齐） */
export const inject = ['agents', 'agentPresets', 'sessions']

/** 插件配置（运行时 schema + 同名类型导出） */
export const Config = A2AConfigSchema
/**
 * plain schema（0.1.5 `installSection` 用）。随 `Config` 一并导出，供测试与
 * 消费方对照：其字段为 plain 标量（无 `.volatile()`），与 `Config` 的 volatile
 * 引用对象输出形成对照。
 */
export const SettingsSchema = A2ASettingsSchema
/**
 * 插件配置类型（plain 形状）。0.2.0 的 settings 服务用运行时 `Config` schema
 * 派生设置区，cordis 在双版本都用它解析 entry config；解析后每个字段会变成
 * volatile 引用对象（`{ get() }`），故运行时读配置一律经 `unwrapVolatile` 解包。
 * 本类型保持 plain 标量形状以免破坏既有引用与类型声明。
 */
export type Config = A2ASettings

/** 逐请求携带执行模式（同步 / 流式）：HTTP 层写入，execute 内读取 */
const executionMode = new AsyncLocalStorage<{ streaming: boolean }>()

/** 运行时配置（apply 时从 config / settings / 环境初始化，提供安全默认值） */
const runtimeConfig = {
  provider: 'deepseek-official',
  // 空字符串 = 不覆盖 model，跟随 dsh 的用户/默认设置；显式配置则覆盖
  model: 'deepseek-v4-flash',
  preset: 'standard',
  authToken: '',
  cwd: '',
  port: undefined as number | undefined,
  host: undefined as string | undefined,
  contextMapPath: undefined as string | undefined,
  contextMapTtlDays: 7,
}

/** 构造一个纯文本 Part */
function textPart(value: string): Part {
  return {
    content: { $case: 'text', value },
    metadata: undefined,
    filename: '',
    mediaType: 'text/plain',
  }
}

/** 构造一个结构化 data Part（私有扩展：承载思考/工具/状态等中间事件） */
function dataPart(value: unknown): Part {
  return {
    content: { $case: 'data', value },
    metadata: undefined,
    filename: '',
    mediaType: 'application/json',
  }
}

/** 从 A2A user message 提取文本（拼接所有 text part） */
function userMessageText(message: { parts: Part[] }): string {
  return message.parts
    .map((p) => (p.content?.$case === 'text' ? p.content.value : ''))
    .join('\n')
    .trim()
}

/** cwd realpath 规范化（解析符号链接与 .. 段），失败回退 resolve */
async function canonicalCwd(raw: string): Promise<string> {
  try {
    return await realpath(raw)
  } catch {
    return resolve(raw)
  }
}

/** 工作区视图（ctx.get('workspaceRegistry')）：可选依赖，headless / 无 workspace 插件的环境自动跳过 */
interface WorkspaceView {
  id: string
  path: string
  sessionIds: readonly SessionId[]
  attachSession?: (sessionId: SessionId) => Promise<void>
}
interface WorkspaceRegistryView {
  create?: (path: string) => Promise<WorkspaceView>
  resolveByPath?: (path: string) => Promise<WorkspaceView | undefined>
  list?: () => WorkspaceView[]
}

/** resolveByPath ?? create，幂等；无 workspaceRegistry 时返回 undefined */
async function ensureWorkspace(ctx: Context, canonical: string): Promise<WorkspaceView | undefined> {
  const registry = ctx.get('workspaceRegistry') as WorkspaceRegistryView | undefined
  if (!registry) return undefined
  return (await registry.resolveByPath?.(canonical)) ?? (await registry.create?.(canonical))
}

/**
 * 把会话挂名到其 cwd 对应的工作区。官方 attachSession 强校验 realpath(header.cwd)
 * 精确等于 workspace.path，所以 canonical 必须是 header.cwd 的 realpath 规范化值；
 * 失败仅告警不阻断任务（分组是锦上添花）。
 */
async function attachToWorkspace(ctx: Context, canonical: string, sessionId: SessionId): Promise<void> {
  try {
    const ws = await ensureWorkspace(ctx, canonical)
    if (ws?.attachSession) await ws.attachSession(sessionId)
  } catch (e) {
    console.warn('[dsh-a2a-server] workspace attach failed:', (e as Error)?.message ?? e)
  }
}

/** 按会话 header 的 cwd（realpath 规范化后）补挂工作区；header 无 cwd 时静默跳过 */
async function attachSessionCwd(ctx: Context, sessionId: SessionId, cwd: string | undefined): Promise<void> {
  if (cwd === undefined) return
  await attachToWorkspace(ctx, await canonicalCwd(cwd), sessionId)
}

/** 读取 HTTP 请求体为 UTF-8 字符串 */
function readBody(req: http.IncomingMessage): Promise<string> {
  return new Promise((resolveBody, rejectBody) => {
    const chunks: Buffer[] = []
    req.on('data', (c: Buffer) => chunks.push(c))
    req.on('end', () => resolveBody(Buffer.concat(chunks).toString('utf8')))
    req.on('error', rejectBody)
  })
}

/** 探测端口是否空闲（check-then-listen 的 dev 级探测，竞态可忽略） */
function isPortFree(port: number): Promise<boolean> {
  return new Promise((resolveFree) => {
    const probe = http.createServer()
    probe.once('error', () => resolveFree(false))
    probe.listen(port, '127.0.0.1', () => {
      probe.close(() => resolveFree(true))
    })
  })
}

// ── contextId 会话映射（P1）────────────────────────────────────────────
// 键 `${contextId}\0${cwd}` → sessionId（同 harness-mcp-server 的 origin-map
// 格式）。同 contextId 复用同一 dsh 会话；映射持久化跨重启 resume。

/** 映射条目：sessionId + 最近使用时间戳（TTL 清理依据） */
interface ContextMapEntry {
  sessionId: string
  lastUsedAt: number
}

/** 常驻内存映射：复合键（contextId\0cwd）→ { sessionId, lastUsedAt } */
const contextMap = new Map<string, ContextMapEntry>()

/** 映射落盘路径；apply() 解析 dshHomePath 服务后赋值 */
let contextMapPath: string | null = null

/** 映射落盘串行链（避免并发写交错） */
let contextMapWriteChain = Promise.resolve()

/** 清理超期条目（lastUsedAt 超过 TTL 天）；返回清理数 */
function cleanupContextMap(): number {
  const ttlMs = runtimeConfig.contextMapTtlDays * 24 * 60 * 60 * 1000
  const now = Date.now()
  let removed = 0
  for (const [k, entry] of contextMap) {
    if (now - entry.lastUsedAt > ttlMs) {
      contextMap.delete(k)
      removed++
    }
  }
  if (removed > 0) console.log(`[dsh-a2a-server] context-map cleanup: removed ${removed} expired entries`)
  return removed
}

/** 读 a2a-context-map.json 回填 contextMap 并清理过期条目（ENOENT 静默空映射） */
async function loadContextMap(): Promise<void> {
  if (contextMapPath === null) return
  try {
    const raw = await readFile(contextMapPath, 'utf8')
    const parsed = JSON.parse(raw) as unknown
    if (parsed && typeof parsed === 'object') {
      for (const [k, v] of Object.entries(parsed as Record<string, unknown>)) {
        // 向后兼容：旧格式 v 为 string（sessionId）；新格式为 { sessionId, lastUsedAt }
        if (typeof v === 'string') {
          contextMap.set(k, { sessionId: v, lastUsedAt: Date.now() })
        } else if (v && typeof v === 'object' && typeof (v as { sessionId?: unknown }).sessionId === 'string') {
          const entry = v as { sessionId: string; lastUsedAt?: unknown }
          contextMap.set(k, {
            sessionId: entry.sessionId,
            lastUsedAt: typeof entry.lastUsedAt === 'number' ? entry.lastUsedAt : Date.now(),
          })
        }
      }
    }
    cleanupContextMap()
  } catch (e) {
    if ((e as { code?: string }).code !== 'ENOENT') {
      console.warn('[dsh-a2a-server] context-map load failed:', (e as Error)?.message ?? e)
    }
  }
}

/** 串行落盘 contextMap（先清理过期 → 快照 → mkdir → tmp 写 → rename 原子覆盖）；失败仅 warn 不阻断 */
function persistContextMap(): Promise<void> {
  contextMapWriteChain = contextMapWriteChain.then(async () => {
    if (contextMapPath === null) return
    cleanupContextMap()
    const snapshot = JSON.stringify(Object.fromEntries(contextMap), null, 2)
    const tmp = `${contextMapPath}.tmp`
    try {
      await mkdir(dirname(contextMapPath), { recursive: true })
      await writeFile(tmp, snapshot)
      await rename(tmp, contextMapPath)
    } catch (e) {
      console.warn('[dsh-a2a-server] context-map persist failed:', (e as Error)?.message ?? e)
    }
  })
  return contextMapWriteChain
}

/** 会话解析结果：disposeAfter = true 表示任务毕须 flush + dispose 释放句柄 */
interface ResolvedSession {
  sessionId: SessionId
  handle: AgentHandle
}

/** 流式中间事件描述符（dsh 会话事件 → 高信号映射，见 runDshTask 的订阅器） */
interface StreamEventDescriptor {
  kind: 'text' | 'thinking' | 'tool_call' | 'tool_result' | 'turn_start' | 'turn_end'
  turn?: number
  step?: number
  text?: string
  name?: string
  arguments?: string
  reason?: string
}

/** 组装 agent 的 provider/model/preset 选项（创建与 resume 共用的 agentOptions + setup） */
function agentComposition(ctx: Context) {
  return {
    agentOptions: {
      provider: runtimeConfig.provider,
      // model 为空则省略，让 dsh 跟随用户/默认设置
      ...(runtimeConfig.model ? { model: runtimeConfig.model } : {}),
    },
    setup: async (agentCtx: Context) => {
      // dsh rc.6 bug 兜底：setup 收到的 agent ctx 可能丢 scope tag，
      // 无 scope 时跳过挂载（降级为无工具 agent），避免整体崩溃
      if (scopeOf(agentCtx) === undefined) {
        console.warn('[dsh-a2a-server] agent ctx unscoped; preset mount skipped')
        return
      }
      await ctx.agentPresets.mount(agentCtx, runtimeConfig.preset)
    },
  }
}

/**
 * 解析（或新建）contextId 对应的 dsh 会话。两级接管：
 * 映射命中 → `ctx.agents.resume`（失败懒删映射落到新建分支）；未命中 → 新建 + 写映射。
 */
async function resolveSession(
  ctx: Context,
  cwd: string,
  contextId: string,
): Promise<ResolvedSession> {
  const key = `${contextId}\u0000${cwd}`
  const mapped = contextMap.get(key)
  if (mapped !== undefined) {
    const sid = SessionId(mapped.sessionId)
    try {
      const handle = await ctx.agents.resume({
        resumeSessionId: sid,
        ...agentComposition(ctx),
      })
      // 命中：刷新最近使用时间戳（TTL 依据）
      mapped.lastUsedAt = Date.now()
      // 接管：幂等补挂工作区（attachToWorkspace 内部已 try/catch 仅 warn）
      await attachSessionCwd(ctx, sid, handle.agent.session.header.cwd)
      return { sessionId: sid, handle }
    } catch (e) {
      // resume 失败（会话已删/损坏/版本不兼容）：懒删映射，落到下方新建分支（不抛错）。
      // A9 诊断：打印真实异常（name/code/message/stack 头 3 行）并明确降级语义，
      // 便于定位 0.2.0 的 v3→v4 resume 失败原因；降级行为不变（删映射 + 新建）。
      contextMap.delete(key)
      void persistContextMap()
      const err = e as { name?: string; code?: string; message?: string; stack?: string }
      const stackHead = String(err.stack ?? '')
        .split('\n')
        .slice(0, 3)
        .join('\n  ')
      console.warn(
        `[dsh-a2a-server] contextId resume failed — falling back to a NEW session (contextId mapping dropped)` +
          `\n  name: ${err.name ?? '(unknown)'}, code: ${err.code ?? '(none)'}, message: ${err.message ?? String(e)}` +
          (stackHead ? `\n  stack:\n  ${stackHead}` : ''),
      )
    }
  }
  const newSessionId = SessionId(randomUUID())
  const handle = await ctx.agents.create({
    sessionId: newSessionId,
    ...agentComposition(ctx),
    meta: { cwd, agentPreset: runtimeConfig.preset },
  })
  contextMap.set(key, { sessionId: String(newSessionId), lastUsedAt: Date.now() })
  void persistContextMap()
  // 分组：把会话归属到 cwd 对应的工作区（resolveByPath ?? create + attachSession；可选依赖；headless 环境自动跳过）
  void (async () => {
    try {
      const ws = await ensureWorkspace(ctx, cwd)
      if (ws?.attachSession) await ws.attachSession(newSessionId)
    } catch (e) {
      console.warn('[dsh-a2a-server] workspace attach failed:', (e as Error)?.message ?? e)
    }
  })()
  return { sessionId: newSessionId, handle }
}

/**
 * 把 A2A task 映射为一次 dsh agent 同步执行（最小版：每次新建独立会话）。
 * `execute` 按 A2A 规范发布 task → statusUpdate(working) → artifact →
 * statusUpdate(completed) 事件流；dsh 执行抛错时异常向上传播，由
 * DefaultRequestHandler 合成 FAILED 状态返回给客户端。
 */
class DshAgentExecutor implements AgentExecutor {
  private readonly cancelled = new Set<string>()

  constructor(private readonly ctx: Context) {}

  async cancelTask(taskId: string, _eventBus: ExecutionEventBus): Promise<void> {
    this.cancelled.add(taskId)
  }

  async execute(requestContext: RequestContext, eventBus: ExecutionEventBus): Promise<void> {
    const taskId = requestContext.taskId
    const contextId = requestContext.contextId
    const userMessage = requestContext.userMessage
    const text = userMessageText(userMessage)
    // 同步 SendMessage 与流式 SendStreamingMessage 复用本 execute；同步时只应
    // 返回最终结果文本，中间事件不得作为 artifact 泄露进 task.artifacts
    const streaming = executionMode.getStore()?.streaming ?? false

    try {
      // 1. 每个执行流必须以 task 事件开头
      eventBus.publish(
        AgentEvent.task({
          id: taskId,
          contextId,
          status: {
            state: TaskState.TASK_STATE_SUBMITTED,
            timestamp: new Date().toISOString(),
            message: undefined,
          },
          artifacts: [],
          history: [userMessage],
          metadata: userMessage.metadata,
        }),
      )

      // 2. working 状态
      eventBus.publish(
        AgentEvent.statusUpdate({
          taskId,
          contextId,
          status: {
            state: TaskState.TASK_STATE_WORKING,
            timestamp: new Date().toISOString(),
            message: undefined,
          },
          metadata: {},
        }),
      )

      // 3. dsh 真实执行（按 contextId 复用/新建会话 → followup → whenIdle → 读最终文本），
      //    期间把高信号中间事件实时推为 A2A 流式 artifactUpdate
      const resultText = await this.runDshTask(text, contextId, (desc) => {
        // 仅流式模式 emit 中间 artifactUpdate；同步模式直接丢弃，避免污染 artifacts
        if (!streaming) return
        if (desc.kind === 'text') {
          // 文本块：append 到共享 'stream-text' artifact（客户端拼接成连续文本流）
          eventBus.publish(
            AgentEvent.artifactUpdate({
              taskId,
              contextId,
              artifact: {
                artifactId: 'stream-text',
                name: 'StreamText',
                description: '流式文本块',
                parts: [textPart(desc.text ?? '')],
                metadata: undefined,
                extensions: [],
              },
              append: true,
              lastChunk: false,
              metadata: undefined,
            }),
          )
        } else {
          // 思考/工具/状态：data Part 私有扩展（JSON 描述符）
          eventBus.publish(
            AgentEvent.artifactUpdate({
              taskId,
              contextId,
              artifact: {
                artifactId: randomUUID(),
                name: 'StreamEvent',
                description: '流式中间事件',
                parts: [dataPart(desc)],
                metadata: undefined,
                extensions: [],
              },
              append: false,
              lastChunk: false,
              metadata: undefined,
            }),
          )
        }
      })

      if (this.cancelled.has(taskId)) {
        eventBus.publish(
          AgentEvent.statusUpdate({
            taskId,
            contextId,
            status: {
              state: TaskState.TASK_STATE_CANCELED,
              timestamp: new Date().toISOString(),
              message: undefined,
            },
            metadata: {},
          }),
        )
        return
      }

      // 4. artifact（最终输出）
      eventBus.publish(
        AgentEvent.artifactUpdate({
          taskId,
          contextId,
          artifact: {
            artifactId: randomUUID(),
            name: 'Result',
            description: 'dsh agent 的最终输出',
            parts: [textPart(resultText)],
            metadata: undefined,
            extensions: [],
          },
          append: false,
          lastChunk: true,
          metadata: undefined,
        }),
      )

      // 5. completed
      eventBus.publish(
        AgentEvent.statusUpdate({
          taskId,
          contextId,
          status: {
            state: TaskState.TASK_STATE_COMPLETED,
            timestamp: new Date().toISOString(),
            message: undefined,
          },
          metadata: undefined,
        }),
      )
    } finally {
      this.cancelled.delete(taskId)
    }
  }

  /** 按 contextId 解析 dsh 会话执行任务，返回最终 assistant 文本；句柄任务毕 flush + 释放 */
  private async runDshTask(
    text: string,
    contextId: string,
    onEvent: (desc: StreamEventDescriptor) => void,
  ): Promise<string> {
    const cwd = await canonicalCwd(runtimeConfig.cwd || process.cwd())
    const { sessionId, handle } = await resolveSession(this.ctx, cwd, contextId)

    try {
      const baseline = ((handle.agent.session as unknown as { log?: unknown[] }).log ?? []).length

      // 流式订阅（任务级，任务毕在 finally 释放）：
      //  - 0.1.5：`session/event`，按会话 id 过滤；`assistant/chunk` 与其他高信号
      //    事件都从这里取。
      //  - 0.2.0：实时助手增量改由进程内 cordis 事件 `agent/assistant-stream`
      //    发布（payload { agent, frame }），`session/event` 不再有
      //    `assistant/chunk`（这正是 0.4.0 直播流没有 thinking/text 帧的根因）。
      // 两面共用同一个缓冲状态机（chunk 是同一 StreamChunk 联合类型），并按
      // agent 对象身份过滤——插件 ctx 非 agent-scoped，会收到同一宿主内所有
      // agent 的帧。
      const ingest = createAssistantIngestState()
      const callNames = new Map<string, string>()
      // A1 兜底探测：投递后是否真的驱动出了 turn（见下方 deliver 的重试逻辑）
      let turnStarted = false
      // 活会话格式版本（v3=0.1.x / v4=0.2.0 起）既是 A1 选 source 形状的依据，
      // 也是「要不要订阅进程内增量面」的第二路运行时信号。
      const sessionVersion = (handle.agent.session as unknown as { header?: { version?: unknown } })
        .header?.version
      const sessionFormatVersion = typeof sessionVersion === 'number' ? sessionVersion : undefined
      // 0.2.0 起才有 agent/assistant-stream：版本谓词（探测失败按真，见 compat）
      // 或活会话 v4 任一命中即订阅，避免插件自身 node_modules 里的滞后版本误判。
      const useRuntimeStream =
        supportsAssistantStreamEvents(dshRuntimeVersion()) || (sessionFormatVersion ?? 0) >= 4
      // 进程内帧的 turn/step 只在 start 帧出现，chunk 帧沿用最近一次 start 的值。
      let streamTurn: number | undefined
      let streamStep: number | undefined
      // 0.1.x 的编译期类型里没有该事件（本包 devDep 按 0.1.x 做类型检查），
      // 局部收窄 ctx.on 的签名；该事件名在旧宿主上是否发布由宿主决定。
      const onRuntimeEvent = this.ctx.on as unknown as (
        event: string,
        listener: (payload: unknown) => void,
      ) => () => void
      const disposeStream = useRuntimeStream
        ? onRuntimeEvent('agent/assistant-stream', (payload) => {
            const { agent, frame } = (payload ?? {}) as {
              agent?: unknown
              frame?: AssistantStreamFrameView
            }
            if (agent !== handle.agent) return
            const turnStep = assistantStreamTurnStep(frame)
            if (turnStep.turn !== undefined) streamTurn = turnStep.turn
            if (turnStep.step !== undefined) streamStep = turnStep.step
            for (const delta of applyAssistantStreamFrame(ingest, frame)) {
              onEvent({ kind: delta.kind, turn: streamTurn, step: streamStep, text: delta.text })
            }
          })
        : () => {}
      const dispose = this.ctx.on('session/event', (session, event) => {
        const sid = (session as { header?: { id?: unknown }; id?: unknown }).header?.id
          ?? (session as { id?: unknown }).id
        if (String(sid) !== String(sessionId)) return
        const ev = event as { type?: string; data?: {
          turn?: number
          step?: number
          name?: string
          arguments?: string
          callId?: string
          reason?: { kind?: string }
          chunk?: { type?: string; blockType?: string; index?: number; text?: string; block?: { type?: string } }
          // v3：content[0] 是 tool-result 包装块（toolCallId + 嵌套 content）；
          // v4（0.2.0）：toolCallId 在 message 层、content 展平为文本块
          message?: { toolCallId?: string; content?: { type?: string; text?: string; toolCallId?: string; content?: { type?: string; text?: string }[] }[] }
        } }
        const data = ev.data ?? {}
        switch (ev.type) {
          case 'assistant/chunk': {
            // 0.1.5 路径；若本任务已收到 0.2.0 的进程内帧，状态机内部静默丢弃
            //（去重门，见 compat.applySessionAssistantChunk）。
            for (const delta of applySessionAssistantChunk(ingest, data.chunk)) {
              onEvent({ kind: delta.kind, turn: data.turn, step: data.step, text: delta.text })
            }
            return
          }
          case 'turn/start':
            // A1 兜底探测：turn 真的开始了 → 本次投递的 source 形状已被运行时接受
            turnStarted = true
            onEvent({ kind: 'turn_start', turn: data.turn, step: data.step })
            return
          case 'turn/end':
            onEvent({ kind: 'turn_end', turn: data.turn, step: data.step, reason: data.reason?.kind })
            return
          case 'tool/call':
            if (data.callId !== undefined && data.name !== undefined) callNames.set(data.callId, data.name)
            onEvent({ kind: 'tool_call', turn: data.turn, step: data.step, name: data.name, arguments: data.arguments })
            return
          case 'tool/result': {
            // tool/result 不带 name（在 tool/call 里）；用 toolCallId 关联名称。
            // A2：v3（0.1.5）/v4（0.2.0）双形状读取见 src/compat.ts readToolResult。
            const read = readToolResult(data)
            onEvent({
              kind: 'tool_result',
              turn: data.turn,
              step: data.step,
              name: read.callId !== undefined ? callNames.get(read.callId) : undefined,
              text: read.text,
            })
            return
          }
          default:
            return
        }
      })

      try {
        // A1：消息 source 形状按**活会话的格式版本**选择（运行时信号，不依赖插件
        // 自己 node_modules 里可能滞后的 dsh 版本）：v4（dsh 0.2.0 起）用命名空间化
        // `{ kind: 'plugin:dsh-a2a-server' }`，v3（0.1.x）用 `{ kind: 'plugin', plugin: … }`。
        // 旧形状在 0.2.0 上会让消息进不了 loop（任务静默不执行），故再加一层兜底：
        // 首选形状未驱动出 turn/start 时换另一种形状重试一次，仍无则响亮告警。
        const preferred = sourceModeForSessionVersion(sessionFormatVersion)

        const deliver = async (mode: PluginMessageSourceMode): Promise<boolean> => {
          turnStarted = false
          handle.agent.followup(
            createUserMessage({
              content: [{ type: 'text', text }],
              // 0.2.0 的命名空间 kind 不在 0.1.x 编译期类型里（本包 devDep 按 0.1.x
              // 做类型检查），此处做一处局部收窄；运行时形状由 compat 保证。
              source: pluginMessageSourceFor(mode) as unknown as { kind: 'plugin'; plugin: string },
            }),
          )
          const deadline = Date.now() + TURN_START_GRACE_MS
          while (!turnStarted && Date.now() < deadline) {
            await new Promise((resolve) => setTimeout(resolve, 50))
          }
          return turnStarted
        }

        if (!(await deliver(preferred))) {
          const alternate: PluginMessageSourceMode = preferred === 'namespaced' ? 'legacy' : 'namespaced'
          console.warn(
            `[dsh-a2a-server] no turn started within ${TURN_START_GRACE_MS}ms with the ${preferred} ` +
              `message source shape (session format v${String(sessionVersion)}); retrying with ${alternate}`,
          )
          if (!(await deliver(alternate))) {
            console.warn(
              '[dsh-a2a-server] no turn started with either message source shape — the task will ' +
                'produce no assistant output; see CONFIGURATION dsh 0.1.5 / 0.2.0 compatibility',
            )
          }
        }
        await handle.agent.whenIdle()
      } finally {
        // 两条订阅同一生命周期：任务毕一并释放（进程内帧订阅可能为 no-op）
        disposeStream()
        dispose()
      }

      // 读本次任务的最终 assistant 文本
      const log = ((handle.agent.session as unknown as { log?: unknown[] }).log ?? []).slice(baseline)
      let out = ''
      for (const e of log) {
        const ev = e as { type?: string; data?: { message?: { content?: { type?: string; text?: string }[] } } }
        if (ev.type === 'assistant/message') {
          const content = ev.data?.message?.content
          if (content) {
            out += content.filter((c) => c.type === 'text' && c.text).map((c) => c.text).join('\n') + '\n'
          }
        }
      }
      return out.trim() || '(no text output)'
    } finally {
      // 跨重启 resume 依赖会话已持久化：任务毕 flush，再释放句柄
      try {
        await (this.ctx.get('sessions') as { flush?: (s: unknown) => Promise<unknown> } | undefined)?.flush?.(handle.agent.session)
      } catch {
        /* flush 失败不阻断结果返回 */
      }
      try {
        await handle.dispose()
      } catch {
        /* 释放失败不影响结果 */
      }
    }
  }
}

/** 构造 agent card（url 用实际监听地址，JSONRPC binding，协议版本 1.0） */
function buildAgentCard(host: string, port: number): AgentCard {
  const base = `http://${host}:${port}/`
  return {
    name: 'dsh',
    description: 'DeepSeek Harness agent exposed over the A2A protocol.',
    supportedInterfaces: [
      {
        url: base,
        protocolBinding: 'JSONRPC',
        tenant: '',
        protocolVersion: A2A_PROTOCOL_VERSION,
      },
    ],
    provider: {
      organization: 'deepseek',
      url: 'https://github.com/deepseek-ai',
    },
    version: '0.5.0',
    capabilities: {
      streaming: true,
      pushNotifications: false,
      extensions: [],
      extendedAgentCard: false,
    },
    securitySchemes: {},
    securityRequirements: [],
    defaultInputModes: ['text'],
    defaultOutputModes: ['text', 'task-status'],
    skills: [
      {
        id: 'dsh_task',
        name: 'dsh task',
        description: '执行编码 / 分析 / 命令类任务',
        tags: ['coding', 'task'],
        examples: ['列出当前目录前 5 个文件并告诉我总数'],
        inputModes: ['text'],
        outputModes: ['text', 'task-status'],
        securityRequirements: [],
      },
    ],
    documentationUrl: '',
    signatures: [],
  }
}

/**
 * 按整份 resolved 值覆盖 runtimeConfig（缺失字段回落安全默认，不做真值守卫：
 * 空串/空值也按其既有语义落库），再施加环境令牌的最高优先级。entry config
 * 初始化与 settings 每次 onChange 共用本函数，保证「清空字段/清除覆盖」之后
 * 行为与面板显示一致。
 */
function applyResolvedConfig(resolved: A2ASettings): void {
  // 导出运行时 Config（volatile）后，双版本的 entry config 字段都会变成
  // `{ get() }` 引用对象（0.1.5 的 settings onChange 则是 plain 标量）；统一
  // 深解包后按 plain 形状读取，缺失字段回落安全默认（不做真值守卫）。
  const r = unwrapVolatile(resolved) as A2ASettings
  runtimeConfig.provider = r.provider ?? 'deepseek-official'
  runtimeConfig.model = r.model ?? 'deepseek-v4-flash'
  runtimeConfig.preset = r.preset ?? 'standard'
  runtimeConfig.cwd = r.cwd ?? ''
  runtimeConfig.authToken = r.authToken ?? ''
  runtimeConfig.port = r.port
  runtimeConfig.host = r.host
  runtimeConfig.contextMapPath = r.contextMapPath
  runtimeConfig.contextMapTtlDays = r.contextMapTtlDays ?? 7
  // 环境变量是最简外部通道，优先级最高（settings 写入也压不过它）
  if (process.env.A2A_SERVER_TOKEN) runtimeConfig.authToken = process.env.A2A_SERVER_TOKEN
  // 每次配置被应用时打一行不含任何密钥的信息日志（authToken 只报有无）
  console.log(
    `[dsh-a2a-server] settings applied: provider=${runtimeConfig.provider} model=${runtimeConfig.model}` +
    ` preset=${runtimeConfig.preset} cwd=${runtimeConfig.cwd || '(process.cwd())'}` +
    ` port=${runtimeConfig.port ?? '(auto)'} host=${runtimeConfig.host ?? '(default 127.0.0.1)'}` +
    ` contextMapPath=${runtimeConfig.contextMapPath ?? '(default)'}` +
    ` contextMapTtlDays=${runtimeConfig.contextMapTtlDays}` +
    ` authToken=${runtimeConfig.authToken ? '<set>' : '<unset>'}`,
  )
}

/**
 * 存量捞回：把现存未分组的会话补挂到已注册工作区。
 * 由 ctx.inject(['workspaceRegistry', 'sessionPersistence']) 在两服务就绪后调用。
 * 条件：header.cwd 的 realpath 等于某已注册 workspace.path，且该 sessionId 不在其花名册里。
 * 只补挂到「已注册」工作区，不新建（避免把无关目录刷成新工作区）；单会话失败不影响其余。
 */
async function reattachOrphanSessions(ctx: Context): Promise<{ attached: number; failed: number }> {
  const registry = ctx.get('workspaceRegistry') as WorkspaceRegistryView | undefined
  const byPath = new Map<string, WorkspaceView>()
  for (const ws of registry?.list?.() ?? []) byPath.set(ws.path, ws)
  if (byPath.size === 0) {
    console.warn('[dsh-a2a-server] 存量捞回: workspaceRegistry 无可注册工作区，跳过')
    return { attached: 0, failed: 0 }
  }

  // live + 持久化 header 合并（live 优先），按 id 去重
  const headers = new Map<string, SessionHeader>()
  const sessions = ctx.get('sessions') as { list?: () => { header: SessionHeader }[] } | undefined
  for (const session of sessions?.list?.() ?? []) headers.set(session.header.id, session.header)
  // sessionPersistence.list() 返回持久化快照（{ header, ... }），需解包出 header
  const persistence = ctx.get('sessionPersistence') as
    | { list?: () => Promise<readonly { header: SessionHeader }[]> }
    | undefined
  for (const snapshot of (await persistence?.list?.()) ?? []) {
    if (!headers.has(snapshot.header.id)) headers.set(snapshot.header.id, snapshot.header)
  }

  let attached = 0
  let failed = 0
  for (const header of headers.values()) {
    if (header.cwd === undefined) continue
    const canonical = await canonicalCwd(header.cwd)
    const ws = byPath.get(canonical)
    if (ws === undefined || !ws.attachSession) continue
    if (ws.sessionIds.includes(header.id)) continue
    try {
      await ws.attachSession(header.id)
      attached++
      console.log(`[dsh-a2a-server] 存量捞回: session ${header.id} -> workspace ${ws.path}`)
    } catch (e) {
      failed++
      console.warn(`[dsh-a2a-server] 存量捞回失败 session ${header.id}:`, (e as Error)?.message ?? e)
    }
  }
  return { attached, failed }
}

/**
 * 插件入口：初始化运行时配置，探测端口，启动 node:http listener 挂
 * JsonRpcTransportHandler，通过 ctx.effect 注册 dispose（关 server）。
 */
export async function apply(ctx: Context, config: Config = {}): Promise<void> {
  // 1) entry config 先落 runtimeConfig（安全默认值 + 环境令牌优先级）
  applyResolvedConfig(config)

  // 2) 挂载 settings 命名空间：installSection attach 时会同步 apply 一次
  //    resolved 值（schema 默认 < base < user），之后每次 commit 都重新 apply；
  //    settings 缺失/注册失败时保持上面的 entry config 结果不变。
  installA2ASettings(ctx, config, applyResolvedConfig)

  // 3) settings 层就绪后才解析路径与监听地址，让用户层在首次 listen 前生效
  const dshHome = ctx.get('dshHomePath') as ((...segments: string[]) => string) | undefined
  contextMapPath = runtimeConfig.contextMapPath
    ?? (dshHome ? dshHome('storages', 'a2a-context-map.json') : join(homedir(), '.dsh', 'storages', 'a2a-context-map.json'))
  await loadContextMap()

  const host = runtimeConfig.host ?? '127.0.0.1'
  const port = runtimeConfig.port ?? (await probePort())

  const agentCard = buildAgentCard(host, port)
  const taskStore = new InMemoryTaskStore()
  const executor = new DshAgentExecutor(ctx)
  const requestHandler = new DefaultRequestHandler(agentCard, taskStore, executor)
  const transport = new JsonRpcTransportHandler(requestHandler)

  const server = http.createServer(async (req, res) => {
    // Bearer token 认证（配置了 authToken 时强制所有请求校验）
    if (runtimeConfig.authToken) {
      const auth = req.headers.authorization
      if (auth !== `Bearer ${runtimeConfig.authToken}`) {
        res.writeHead(401, { 'Content-Type': 'application/json' })
        res.end(JSON.stringify({ jsonrpc: '2.0', error: { code: -32001, message: 'Unauthorized' }, id: null }))
        return
      }
    }

    try {
      // agent card 公开端点
      if (req.method === 'GET' && (req.url === `/${AGENT_CARD_PATH}` || req.url === `/${AGENT_CARD_PATH}/`)) {
        res.writeHead(200, { 'Content-Type': 'application/json' })
        res.end(JSON.stringify(await requestHandler.getAgentCard()))
        return
      }

      // JSON-RPC 端点
      if (req.method === 'POST' && (req.url === '/' || req.url === '')) {
        const rawBody = await readBody(req)
        // 从 JSON-RPC method 判定是否流式，经 AsyncLocalStorage 传给 executor：
        // 同步 SendMessage 不 emit 中间 artifactUpdate，只返回最终结果文本
        let isStreaming = false
        try {
          const method = (JSON.parse(rawBody) as { method?: unknown }).method
          isStreaming = method === 'SendStreamingMessage' || method === 'SubscribeToTask'
        } catch {
          /* 非 JSON 请求体按非流式处理 */
        }
        const requestedVersion =
          (req.headers['a2a-version'] as string | undefined) ?? A2A_PROTOCOL_VERSION
        await executionMode.run({ streaming: isStreaming }, async () => {
          const context = new ServerCallContext({ requestedVersion })
          const rpcResult = await transport.handle(rawBody, context)
          if (typeof (rpcResult as unknown as { [Symbol.asyncIterator]?: unknown })[Symbol.asyncIterator] === 'function') {
            // 流式（SendStreamingMessage / SubscribeToTask）→ SSE
            res.writeHead(200, {
              'Content-Type': 'text/event-stream',
              'Cache-Control': 'no-cache',
              Connection: 'keep-alive',
            })
            for await (const ev of rpcResult as AsyncGenerator<unknown, void, undefined>) {
              res.write(formatSSEEvent(ev))
            }
            res.end()
          } else {
            res.writeHead(200, { 'Content-Type': 'application/json' })
            res.end(JSON.stringify(rpcResult))
          }
        })
        return
      }

      res.writeHead(404, { 'Content-Type': 'application/json' })
      res.end(JSON.stringify({ error: 'Not found' }))
    } catch (e) {
      console.error('[dsh-a2a-server] request error:', (e as Error)?.message ?? e)
      if (!res.headersSent) {
        res.writeHead(500, { 'Content-Type': 'application/json' })
        res.end(
          JSON.stringify({
            jsonrpc: '2.0',
            error: { code: -32603, message: String((e as Error)?.message ?? e) },
            id: null,
          }),
        )
      }
    }
  })

  server.on('error', (e) => {
    console.error('[dsh-a2a-server] HTTP server error:', (e as Error).message)
  })

  // listen 转 Promise：'error' 只作为本次 listen 的失败通道，成功后移除
  await new Promise<void>((resolveListen, rejectListen) => {
    const onError = (e: Error) => rejectListen(e)
    server.once('error', onError)
    server.listen(port, host, () => {
      server.removeListener('error', onError)
      resolveListen()
    })
  })
  console.log(`[dsh-a2a-server] A2A server listening on ${host}:${port}`)

  // 存量捞回：改为 ctx.inject 运行时依赖，等 workspaceRegistry / sessionPersistence 都就绪（ACTIVE）
  // 后再补挂，修复启动期 registry 尚未就绪时 ctx.get 返回 undefined 导致的静默 attached=0 竞态。
  // 不阻塞启动（apply 不 await），也不进入静态 inject 硬依赖（不推迟插件加载、不破坏 headless）。
  // 依赖重载会卸载并重跑本 callback；幂等性由 ws.sessionIds.includes(header.id) 跳过 + attachSession 幂等保证。
  ctx.inject(['workspaceRegistry', 'sessionPersistence'], () => {
    console.log('[dsh-a2a-server] 存量捞回: workspaceRegistry 就绪，开始补挂')
    // callback 同步返回；异步捞回内部 fire-and-forget，全程兜底 try/catch 防 unhandled rejection
    void (async () => {
      try {
        const { attached, failed } = await reattachOrphanSessions(ctx)
        console.log(`[dsh-a2a-server] 存量捞回: attached=${attached} failed=${failed}`)
      } catch (e) {
        console.warn('[dsh-a2a-server] 存量捞回异常:', (e as Error)?.message ?? e)
      }
    })()
  })

  // 标准 cordis 生命周期：卸载时关闭 server + 清空映射
  ctx.effect(() => {
    return () => {
      server.close()
      contextMap.clear()
    }
  }, 'dsh-a2a-server')
}

/** 探测 8092/8093/8094 首个空闲端口；全占用则报错（fail loud） */
async function probePort(): Promise<number> {
  for (const p of [8092, 8093, 8094]) {
    if (await isPortFree(p)) return p
  }
  throw new Error('[dsh-a2a-server] no free port among 8092/8093/8094')
}
